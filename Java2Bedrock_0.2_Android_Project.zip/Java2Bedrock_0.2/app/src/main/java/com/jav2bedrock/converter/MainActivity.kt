package com.jav2bedrock.converter

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.work.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

private val Bg = Color(0xFF0B0D14)
private val Panel = Color(0xFF171B29)
private val Accent = Color(0xFF8B5CF6)
private val Muted = Color(0xFF9CA3AF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Accent,
            onBackground = Color.White, onSurface = Color.White
        )) { ConverterScreen(this) } }
    }
}

@Composable
fun ConverterScreen(context: Context) {
    val prefs = remember { context.getSharedPreferences("quota", Context.MODE_PRIVATE) }
    var selectedName by remember { mutableStateOf("Ningún archivo seleccionado") }
    var message by remember { mutableStateOf("Selecciona un mod .jar para comenzar") }
    var busy by remember { mutableStateOf(false) }
    var used by remember { mutableIntStateOf(prefs.getInt("used", 0)) }
    val scope = rememberCoroutineScope()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            selectedName = uri.lastPathSegment?.substringAfterLast('/') ?: "Archivo seleccionado"
            message = "Archivo listo. La conversión requiere conectar el motor propio."
            // Keep read access for background processing.
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("JAVA2BEDROCK", style = MaterialTheme.typography.labelLarge, color = Accent)
                    Text("Converter", style = MaterialTheme.typography.headlineLarge)
                    Text("Versión 0.2 · Android", color = Muted)
                }
                Icon(Icons.Default.Settings, contentDescription = "Configuración", tint = Muted)
            }
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("CONVERSIÓN", color = Accent, style = MaterialTheme.typography.labelLarge)
                    Text("Java  →  Bedrock", style = MaterialTheme.typography.headlineMedium)
                    Text(selectedName, color = Muted)
                    Button(onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.CloudUpload, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Seleccionar archivo .JAR")
                    }
                    OutlinedButton(
                        onClick = {
                            if (!isOnline(context)) {
                                message = "Error 206: Necesitas conexión a internet para continuar"
                            } else if (used >= 5) {
                                message = "Límite alcanzado: espera a que termine el periodo de 5 horas."
                            } else {
                                message = "Motor de conversión no conectado todavía. No se ha iniciado ningún trabajo."
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Convertir a Bedrock") }
                    Text(message, color = if (message.startsWith("Error")) Color(0xFFFF8585) else Muted)
                }
            }
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("LÍMITE DE USO", color = Accent, style = MaterialTheme.typography.labelLarge)
                    Text("$used / 5 conversiones")
                    LinearProgressIndicator(progress = { used / 5f }, modifier = Modifier.fillMaxWidth(), color = Accent)
                    Text("Máximo 5 conversiones por ventana de 5 horas.", color = Muted)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.History, contentDescription = null, tint = Muted)
                Spacer(Modifier.width(8.dp))
                Text("Historial", style = MaterialTheme.typography.titleMedium)
            }
            Text("Todavía no hay conversiones.", color = Muted)
            Spacer(Modifier.weight(1f))
            Text("Motor IA propio · Sin API Key · Requiere servidor de conversión", color = Muted, style = MaterialTheme.typography.bodySmall)
        }
    }
}

private fun isOnline(context: Context): Boolean {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val network = cm.activeNetwork ?: return false
    val caps = cm.getNetworkCapabilities(network) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}
