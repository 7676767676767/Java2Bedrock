# Java2Bedrock Converter 0.2 (Android)

Proyecto Android nativo en Kotlin + Jetpack Compose.

## Estado real de esta entrega
Esta es una base instalable/compilable de la aplicación: interfaz, selector de archivos, comprobación de conexión y pantalla de límite. **Todavía no convierte mods**. El motor Java→Bedrock y su servidor propio deben implementarse y desplegarse antes de habilitar conversiones reales.

## Requisitos
- Android Studio reciente
- JDK 17 o 21
- Android SDK Platform 35
- Gradle 8.9 o compatible con Android Gradle Plugin 8.7.3

## Compilar APK
Abre esta carpeta en Android Studio y espera la sincronización de Gradle. Después:
`Build > Build Bundle(s) / APK(s) > Build APK(s)`

APK debug: `app/build/outputs/apk/debug/app-debug.apk`

## Decisiones
- No usa API Key de terceros.
- La app muestra Error 206 si no detecta conexión a internet.
- La conversión se mantiene deshabilitada funcionalmente hasta conectar el backend.
- El límite mostrado es una maqueta inicial; falta implementar el control definitivo de cuota en servidor para evitar reinicios o manipulación local.
- Para trabajo en segundo plano se debe conectar el backend y completar el worker de WorkManager.

## Próxima fase
1. Backend propio con cola de trabajos.
2. Analizador de JAR seguro (sin ejecutar código del mod).
3. Conversión de recursos y generación de `.mcaddon`/`.mcpack`.
4. Motor de reglas/modelo propio, sin API key.
5. Worker de Android con notificación de progreso.
6. Cuota de 5 trabajos por usuario cada 5 horas validada por servidor.
